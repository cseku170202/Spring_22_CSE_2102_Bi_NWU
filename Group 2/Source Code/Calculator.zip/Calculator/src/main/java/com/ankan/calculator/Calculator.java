package com.ankan.calculator;
/**
 *
 * @author ankan
 */
public class Calculator extends frame  {
    
    public static void main(String[] args) {
        frame c = new frame();  
}
}